/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package telas;

import java.awt.BorderLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JToolBar;
import regras.ControleBotoesSelecionados;
import regras.EstadosBotoes;

/**
 *
 * @author EwertonFalcao
 */
public class TelaPrincipal extends JFrame {

    int pontos = 100;
    private JToolBar Barra_Ferramenta = new JToolBar();
    private JButton Button_Novo_Jogo = new JButton("Novo Jogo");
    private JButton Button_Re_Iniciar_Jogo = new JButton("Reiniciar partida");
    private JButton Button_Estatisticas = new JButton("Estatísticas");
    private JButton Sobre_JogoDaMemoria = new JButton("Sobre");

    private JPanel Barra_de_Status = new JPanel();
    private JLabel Pontuacao_do_Jogador = new JLabel("Pontos: 100");

    private static final int QUANTIDADE_JOGADAS = 2;
    private int jogadas = 0;

    private JPanel painel;

    private List<ControleBotoesSelecionados> listaControle;
    private List<ControleBotoesSelecionados> listaSelecionados;

    private ActionListener acaoBotoes;

    public TelaPrincipal() {

        super("Jogo da Memoria");
        Barra_Ferramenta.add(Button_Novo_Jogo);
        Barra_Ferramenta.add(Button_Re_Iniciar_Jogo);
        Barra_Ferramenta.add(Button_Estatisticas);
        Barra_Ferramenta.add(Sobre_JogoDaMemoria);
        add(Barra_Ferramenta, BorderLayout.NORTH);

        //Arraylists
        listaControle = new ArrayList<>();
        listaSelecionados = new ArrayList<>();

        //evento dos botoes
        acaoBotoes = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton botao = (JButton) e.getSource();
                for (ControleBotoesSelecionados cont : listaControle) {
                    if (cont.getReferenciaBotoes().get(botao) != null) {
                        jogadas++;
                        cont.executarAcaoBotoes((JButton) e.getSource(), EstadosBotoes.SELECIONADO);
                        //controle de inclusão
                        if(!listaSelecionados.contains(cont)){
                            listaSelecionados.add(cont);
                        }
                        System.out.println(listaSelecionados.size());
                        if (jogadas == QUANTIDADE_JOGADAS) {
                             if (pontos < 0) pontos = 0;
                                Pontuacao_do_Jogador.setText("Pontos: " + pontos);

                            //Acabaram as jogadas
                            if(listaSelecionados.size() > 1){
                                //só selecionou os botoes corretos
                                for(ControleBotoesSelecionados cbs : listaSelecionados){
                                    int delay = 500;   // delay de 1 seg.
                                    int interval = 1000000;  // intervalo de 10 mil seg.
                                    Timer timer = new Timer();
                                    timer.scheduleAtFixedRate(new TimerTask() {
                                        public void run() {
                                        // colocar tarefas aqui ...
                                    cbs.zerarSelecoes();
                                    }
                                    }, delay, interval);
                                }
                            }
                            jogadas = 0;
                            listaSelecionados.clear();
                        }
                        break;
                    }
            int Partidas_jogadas = 0, Numero_de_Vitorias = 0;
            boolean Novo_Jogo = true;
            boolean Re_Iniciar = false;
            boolean Fim_de_Jogo = false;
            }

            if (e.getSource() == Button_Novo_Jogo){
                boolean Novo_Jogo = true;
                boolean Re_Iniciar = false;
            }

            if (e.getSource() == Button_Re_Iniciar_Jogo){
                boolean Novo_Jogo = true;
                boolean Re_Iniciar = true;
            }

            if (e.getSource() == Button_Estatisticas){
                boolean Fim_de_Jogo = true;
            }
        }
    };

        Barra_de_Status.add(Pontuacao_do_Jogador);
        add(Barra_de_Status, BorderLayout.SOUTH);

        painel = new JPanel();
        this.add(painel);
        painel.setLayout(null);

        this.setBounds(600, 600, 470, 470);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        criarJogo(6);
        this.setVisible(true);
    }
    private void criarJogo(int qtPares){
        //Quantidade de botoes
        ControleBotoesSelecionados controle = null;

        List<Rectangle> posicionamento = new ArrayList<>();
        int posX = 10;
        int posY = 10;

        Random rand = new Random();

        int j = 0;
        int i = 0;
        for(i = 0; i < (qtPares*2) ; i++){
            Rectangle rec = new Rectangle (posX,posY,100,110);
            posicionamento.add(rec);
            if((i + 1) % 4 == 0 && i > 0){
                posY += 120;
                posX = 10;
            }else{
                posX += 110;
            }
        }

        for(i = 0; i < (qtPares*2) ; i++){
            if(i % 2 == 0){
                //Quantidade de controladores
                j++;
                controle = new ControleBotoesSelecionados();
                controle.setNmBotao("MEM" + j);
                this.listaControle.add(controle);
            }
            JButton botao = new JButton("GAME");
            //Coloca botoes na tela
            this.painel.add(botao);
            botao.addActionListener(this.acaoBotoes);
            int pos = rand.nextInt(((posicionamento.size() -1 ) > 0 )? posicionamento.size() -1 : 1);
            System.out.println(pos);
            botao.setBounds(posicionamento.get(pos));
            posicionamento.remove(pos);

            controle.adicionarBotao(botao);

        }


        //Adaptar o tamanho da tela

        //Randomizar o posicionamento dos botoes
    }
}
