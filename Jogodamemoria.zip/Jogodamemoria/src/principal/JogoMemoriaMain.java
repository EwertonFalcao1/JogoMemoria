package principal;

import telas.TelaPrincipal;

/**
 *
 * @author EwertonFalcao
 */
public class JogoMemoriaMain {

    public static void main(String[] args) {
        TelaPrincipal tela = new TelaPrincipal();
        
    }
    
}
