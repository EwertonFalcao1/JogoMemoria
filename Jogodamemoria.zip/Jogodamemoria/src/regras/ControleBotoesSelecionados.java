package regras;

/**
 *
 * @author EwertonFalcao
 */

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JButton;

public class ControleBotoesSelecionados {
    
    private String nmBotao;
    private Map<JButton , EstadosBotoes>ReferenciaBotoes;

    public ControleBotoesSelecionados(){
        
        this.ReferenciaBotoes = new HashMap<>();
    }
    
    public void executarAcaoBotoes(JButton botao, EstadosBotoes estado){
        alterarSelecao(botao, estado);
        if (this.isTodasSelecionadas()){
            alterarEstadoTodosBotoes(EstadosBotoes.PARES_ENCONTRADOS);
        }else{
            alterarVisualizacaoBotao(botao);
        }
    }
    
    private void alterarEstadoTodosBotoes(EstadosBotoes estado){
        for(JButton botao : this.ReferenciaBotoes.keySet()){
            alterarSelecao(botao, estado);
            alterarVisualizacaoBotao(botao);
        }
    }
    
    public String getNmBotao() {
        return nmBotao;
    }

    public void setNmBotao(String nmBotao) {
        this.nmBotao = nmBotao;
    }

    public Map<JButton, EstadosBotoes> getReferenciaBotoes() {
        return ReferenciaBotoes;
    }

    public void setReferenciaBotoes(Map<JButton, EstadosBotoes> ReferenciaBotoes) {
        this.ReferenciaBotoes = ReferenciaBotoes;
    }
    
    public void adicionarBotao(JButton botao){
        
        this.ReferenciaBotoes.put(botao, EstadosBotoes.NORMAL);    
    }
    public void alterarSelecao(JButton botao, EstadosBotoes selecionado){
        this.ReferenciaBotoes.put(botao, selecionado);
        
    }
    
    private void alterarVisualizacaoBotao(JButton botao){
        EstadosBotoes selecionado = this.ReferenciaBotoes.get(botao);
        
        switch (selecionado){
            case NORMAL://cinza não exibe texto
                botao.setBackground(null);
                botao.setText("GAME");
                break;
            case SELECIONADO: // exibir texto, mudar a cor
                botao.setBackground(Color.RED);
                botao.setText(this.nmBotao);
                break;
            case PARES_ENCONTRADOS: // mudar a cor e exibir o texto
                botao.setBackground(Color.PINK);
                botao.setText(this.nmBotao);
                botao.setEnabled(false);
                break;
        }
    }
    
    public void zerarSelecoes(){
        alterarEstadoTodosBotoes(EstadosBotoes.NORMAL);
    }
    public Boolean isTodasSelecionadas(){
        for(EstadosBotoes b : this.ReferenciaBotoes.values()){
            if(b != EstadosBotoes.SELECIONADO){
                // Não foram selecionados
                return false;
            }
        }
        return true;
    }
}
